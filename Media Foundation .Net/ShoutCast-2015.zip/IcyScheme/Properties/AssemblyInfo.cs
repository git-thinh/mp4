﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("IcyScheme")]
[assembly: AssemblyProduct("IcyScheme")]

[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("194cdabf-ef40-4a36-a39e-73164b65c0a4")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
