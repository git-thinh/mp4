WriteText - Write text on frames in video stream.

This sample using GDI+ to write text onto the video stream.

CLSID: FBC659ED-BACD-4F8F-9560-EC26319C935C

Attributes returned from IMFTransform::GetAttributes
None

Input types supported:
MFMediaType_Video + MFVideoFormat_RGB32

Output types supported:
Matches input type.
