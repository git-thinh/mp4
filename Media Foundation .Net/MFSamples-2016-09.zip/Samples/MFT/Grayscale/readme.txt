Grayscale - Convert a video stream to grayscale.

This sample is basically the MS mft_Grayscale sample, re-written to use the framework.

It also shows how to use multiple input types.

This is one of 3 re-writes of the grayscale sample.  This one is synchronous.

CLSID: 69042198-8146-4735-90F0-BEFD5BFAEDB7

Input types supported:
MFMediaType_Video + MFVideoFormat_NV12
MFMediaType_Video + MFVideoFormat_YUY2
MFMediaType_Video + MFVideoFormat_UYVY

Output types supported:
Matches input type.
