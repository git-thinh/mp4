Grayscale - Convert a video stream to grayscale.

This sample is basically the MS mft_Grayscale sample, re-written to use the framework.

It also shows how to use multiple input types.

This is one of 3 re-writes of the grayscale sample.  This one is asynchronous.

CLSID: E6AAA34E-A092-418A-A037-6634EED63CB5

Input types supported:
MFMediaType_Video + MFVideoFormat_NV12
MFMediaType_Video + MFVideoFormat_YUY2
MFMediaType_Video + MFVideoFormat_UYVY

Output types supported:
Matches input type.
