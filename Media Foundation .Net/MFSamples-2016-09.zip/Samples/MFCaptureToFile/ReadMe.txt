/************************************************************************
MFCaptureToFile - Capture from webcam to file with MF

While the underlying library is covered by LGPL or BSD, this sample is released
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

**************************************************************************/

This sample is a c# version of the C++ MFCaptureToFile sample included in the
Media Foundation SDK.  It allows you to select a capture device, and specify
the file name to which to capture.

This thread may also be of interest to people who want to capture audio, or
capture both video and audio:

http://social.msdn.microsoft.com/Forums/en/mediafoundationdevelopment/thread/d6dc8030-7730-448f-8748-7a7279aefeb5

