/************************************************************************
Playlist - Plays a list of audio files

While the underlying library is covered by LGPL or BSD, this sample is released
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

**************************************************************************/

This sample is a c# version of the Playlist sample included in the
Media Foundation SDK.  It plays a collection of media files, one after 
the other.  It still contains some of the odd behavior from the
original.