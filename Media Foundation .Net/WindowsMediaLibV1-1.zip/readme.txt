WindowsMediaLibNET - A library to allow .NET applications to use Windows Media
http://windowsmedianet.sourceforge.net

Licensed under Lesser General Public License.  See license.txt for details.

A collection of samples is available in the download area of the link above.

The documentation is located in docs\readme.rtf and can be read with WordPad, MS Word, etc.

A retail build of the library can be found in lib\WindowsMediaLib.dll

The list of interfaces indicating which are tested or untested can be found in docs\interfaces.txt

The complete source code with definitions for all interfaces (tested and untested) can be found in src\*.*
