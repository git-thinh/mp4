/************************************************************************
ShoutCast - An upgraded version of the PlaybackFX sample that shows song titles.

While the underlying library is covered by LGPL or BSD, this sample is released
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

**************************************************************************/

This sample is the PlaybackFX sample reworked to show song titles if the
specified URL provides them.  This is based on MF's recognition of song
titles that (apparently) only works on Windows 7 (not Vista OR Windows 8).



