/************************************************************************
DrmHeader - Show the DRM attributes of a file

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

**************************************************************************/

This file is based on the DRMHeader sample in the WMF sdk.  It attempts to
show a few more properties than the SDK sample, but the MSDN docs are a little
value about how license data is actually formatted.