/************************************************************************
GenerateLa - Builds (and plays) a wave buffer that contains a beep

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

**************************************************************************/

For people who are interested in seeing what a wave buffer looks like, this
sample builds one.  It creates a buffer that contains a tone at the specified
frequency and then plays it.