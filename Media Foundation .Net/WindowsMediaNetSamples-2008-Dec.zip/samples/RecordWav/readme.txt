/************************************************************************
RecordWav - Record audio data from a microphone to a .wav file

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

**************************************************************************/

A simple class that records audio to a .wav file.  It allows for both creating
new files, and appending recording data to existing files.