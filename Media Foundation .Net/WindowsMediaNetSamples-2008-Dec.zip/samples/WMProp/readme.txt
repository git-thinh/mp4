/************************************************************************
WMProp - Show file properties for WM files

While the underlying libraries are covered by LGPL, this sample is released 
as public domain.  It is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY 
or FITNESS FOR A PARTICULAR PURPOSE.  

**************************************************************************/

This file is based on the WMProp sample in the WMF sdk.  It shows the non-DRM
attributes of WM files.  To view the DRM attributes, check out the DrmHeader
sample.